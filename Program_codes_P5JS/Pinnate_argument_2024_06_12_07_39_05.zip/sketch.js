function setup() {
  createCanvas(400, 400);
  background(100);
}

function draw() {
  fill(250,50);
  ellipse(mouseX,mouseY,50);
  
}

function mousePressed() {
  background("yellow");

}