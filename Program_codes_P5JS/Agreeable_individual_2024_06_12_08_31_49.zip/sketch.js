let song;
let amplitude;

function preload() {
  song = loadSound('Mozart.mp3');
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  song.play();
  amplitude = new p5.Amplitude();
  mySecondColor = color(random(255), random(255), random(255));

}

function draw() {
  background(0);

  let level = amplitude.getLevel();
  let size = map(level, 0, 1, 0, 500);

  fill(mySecondColor);
  noStroke();
  ellipse(width / 2, height / 2, size, size);
}

