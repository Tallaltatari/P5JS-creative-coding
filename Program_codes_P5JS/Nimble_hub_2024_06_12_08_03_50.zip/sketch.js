var img;
function preload() {
  img = loadImage("Animated_whale.jpg");
}

function setup() {
  createCanvas(1280, 720);
  background(0);
  noStroke();
}

function draw() {
  x = random(width);
  y = random(height);
  var c = img.get(x,y);
  fill (c[0], c[1], c[2], 500);
  ellipse (x, y, 30, 30);
}