let barry;
let peaks;

function preload(){
  barry = loadSound("Mozart.mp3");
}

function setup() {
  createCanvas(400, 400);
  peaks = barry.getPeaks(width);
  barry.loop();
}

function draw() {
  background(255,182,193);
  
  stroke(0,0,128);
  for(let i = 0; i < peaks.length; i++){
    line(i, height/2 + peaks[i]*200, i, height/2 -peaks[i]*200);
  }
  
  let t = map(barry.currentTime(), 0, barry.duration(), 0, width)
  
  stroke(255, 255, 190);
  line(t, 0, t, height);
}