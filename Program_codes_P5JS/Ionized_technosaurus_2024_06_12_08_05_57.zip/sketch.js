var numFrames = 6;
var frame = 0;
var images = new Array(numFrames);

function preload() {
  images[1] = loadImage("The shoe that flew title page.jpg");
  images[2] = loadImage("Bedtime-Stories-The-Shoe-That-Flew-short-stories-for-kids-page_1.jpg");
  images[3] = loadImage("Bedtime-Stories-The-Shoe-That-Flew-short-stories-for-kids-page_2.jpg");
  images[4] = loadImage("Bedtime-Stories-The-Shoe-That-Flew-short-stories-for-kids-page_3.jpg");
  images[5] = loadImage("Bedtime-Stories-The-Shoe-That-Flew-short-stories-for-kids-page_4.jpg");
  images[6] = loadImage("Bedtime-Stories-The-Shoe-That-Flew-short-stories-for-kids-page_5.jpg");
}

function setup() {
  createCanvas(1300, 1317);
  frameRate(10);
  background(255);
}

function draw() {
  background(255);
  frame++;
  if(frame == numFrames) frame = 0;
  image(images[frame],mouseX-75,mouseY-100);
}