var img;
function preload() {
  img = loadImage("Zach.jpg");
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  image(img,0,0,img.height/4,img.width/4);
  var v = map(mouseX,0,width,0,5);
  filter(POSTERIZE,v);
}