let song;
let amplitude;
let trail = [];

function preload() {
  song = loadSound('Mozart.mp3'); 
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  song.play();
  amplitude = new p5.Amplitude();
}

function draw() {
  background(0, 50); 

  let level = amplitude.getLevel();
  let size = map(level, 0, 1, 10, 200);

  trail.push({ x: mouseX, y: mouseY, size: size, color: color(random(255), random(255), random(255)) });
 
  if (trail.length > 100) {
    trail.shift();
  }

  for (let i = 0; i < trail.length; i++) {
    let t = trail[i];
    fill(t.color);
    noStroke();
    ellipse(t.x, t.y, t.size, t.size);
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}