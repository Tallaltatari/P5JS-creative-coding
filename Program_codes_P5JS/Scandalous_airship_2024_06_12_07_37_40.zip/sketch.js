function setup() {
  createCanvas(400, 400);
}

function draw() {
  background('#673AB7');
   fill('#F44336');
  noStroke();
  triangle(250,95,300,210,200,210);
  fill("#F44336");
  noStroke();
 square(225,210,55);
  fill("#F44336");
  noStroke();
 square(225,260,55);
}




