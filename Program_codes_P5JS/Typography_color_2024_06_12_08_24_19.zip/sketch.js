var word = "BATH SPA UNIVERSITY" ;
var font1;
function preload(){
  font1= loadFont("Sevillana-Regular.ttf");
}

function setup() {
  createCanvas(600, 600);
  background("blue");
  fill("yellow");
  textFont(font1,50);
  textAlign(CENTER);
  text(word,width/2,height/2);
  
}