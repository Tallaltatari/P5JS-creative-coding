var pic

function preload(){
  pic = loadImage("carimage5.png");
}


function setup() {
  createCanvas(400, 400);
  background(100);
  }

function draw() {
  fill(250,50);
  image(pic, mouseX, mouseY)
  
}

function mousePressed() {
  background("aqua");

}