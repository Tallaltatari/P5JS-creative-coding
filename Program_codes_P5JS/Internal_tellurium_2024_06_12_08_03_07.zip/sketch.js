var img;
function preload() {
  img = loadImage("Zach.jpg");
}

function setup() {
  createCanvas(400, 400);
  background(0);
}

function draw() {
  background(220);
  x = mouseX;
  y = mouseY;
  image(img,0,0,img.height/4,img.width/4);
  var c = get(x,y);
  fill(c);
  ellipse(x,y,100,100)
}