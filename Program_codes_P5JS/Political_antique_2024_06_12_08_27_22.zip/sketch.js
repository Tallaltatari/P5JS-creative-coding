var numbers = [119, 330, 462, 390, 252, 199, 252, 366, 444, 250]


function setup() {
  createCanvas(500, 500);
  colorMode(HSB, 360, 100, 100);

  for (var i=0; i<numbers.length;i++){
  var n = numbers[i];
  fill(random(360), 360, 360)
  rect(i*50,height-n,50,n)
  }
}