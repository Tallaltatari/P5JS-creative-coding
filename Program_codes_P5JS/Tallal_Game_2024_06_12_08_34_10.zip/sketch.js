let player;
let bullets = [];
let targets = [];
let score = 0;
let gameOver = false;
let enemyImg, bgImg, shootSound, gameOverSound;
let gameState = 'welcome'; // 'welcome', 'playing', 'gameover'

function preload() {
  enemyImg = loadImage('alien_pixel.png');
  bgImg = loadImage('space background.jpg'); // Make sure this image is in the same directory
  shootSound = loadSound('laser_game_sound.wav'); // Make sure this sound file is in the same directory
  gameOverSound = loadSound('game_end_sound.wav'); // Make sure this sound file is in the same directory
}

function setup() {
  createCanvas(600, 400);
  player = new Player();
  frameRate(60);
}

function draw() {
  background(bgImg);

  if (gameState === 'welcome') {
    showWelcomeScreen();
  } else if (gameState === 'playing') {
    playGame();
  } else if (gameState === 'gameover') {
    showGameOverScreen();
  }
}

function showWelcomeScreen() {
  fill(255);
  textSize(36);
  textAlign(CENTER, CENTER);
  text("Welcome to the Shooting Game!", width / 2, height / 2 - 40);
  textSize(24);
  text("Press any key to start", width / 2, height / 2 + 40);
}

function playGame() {
  player.update();
  player.show();

  if (frameCount % 60 === 0) {
    targets.push(new Target());
  }

  for (let i = bullets.length - 1; i >= 0; i--) {
    bullets[i].update();
    bullets[i].show();

    if (bullets[i].offScreen()) {
      bullets.splice(i, 1);
    }
  }

  for (let i = targets.length - 1; i >= 0; i--) {
    targets[i].update();
    targets[i].show();

    if (targets[i].offScreen()) {
      gameOver = true;
      gameState = 'gameover';
      gameOverSound.play();
    }

    for (let j = bullets.length - 1; j >= 0; j--) {
      if (targets[i] && bullets[j].hits(targets[i])) {
        targets.splice(i, 1);
        bullets.splice(j, 1);
        score++;
        break;
      }
    }
  }

  fill(255);
  textSize(24);
  text("Score: " + score, 42, 30);
}

function showGameOverScreen() {
  fill(255);
  textSize(36);
  textAlign(CENTER, CENTER);
  text("Game Over", width / 2, height / 2);
  textSize(24);
  text("Score: " + score, width / 2, height / 2 + 40);
  text("Press any key to restart", width / 2, height / 2 + 80);
}

function keyPressed() {
  if (gameState === 'welcome' || gameState === 'gameover') {
    resetGame();
    gameState = 'playing';
  } else if (gameState === 'playing') {
    if (keyCode === LEFT_ARROW) {
      player.move(-1);
    } else if (keyCode === RIGHT_ARROW) {
      player.move(1);
    } else if (keyCode === 32) { // Space bar
      bullets.push(new Bullet(player.x + player.width / 2, player.y));
      shootSound.play();
    }
  }
}

function keyReleased() {
  if (keyCode === LEFT_ARROW || keyCode === RIGHT_ARROW) {
    player.stop();
  }
}

function resetGame() {
  player = new Player();
  bullets = [];
  targets = [];
  score = 0;
  gameOver = false;
}

class Player {
  constructor() {
    this.x = width / 2;
    this.y = height - 20;
    this.width = 50;
    this.height = 20;
    this.xdir = 0;
  }

  update() {
    this.x += this.xdir * 5;
    this.x = constrain(this.x, 0, width - this.width);
  }

  show() {
    fill(255);
    rect(this.x, this.y, this.width, this.height);
  }

  move(dir) {
    this.xdir = dir;
  }

  stop() {
    this.xdir = 0;
  }
}

class Bullet {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.r = 5;
    this.speed = 5;
  }

  update() {
    this.y -= this.speed;
  }

  show() {
    fill(50, 200, 50);
    ellipse(this.x, this.y, this.r * 2);
  }

  offScreen() {
    return this.y < 0;
  }

  hits(target) {
    let d = dist(this.x, this.y, target.x, target.y);
    return d < this.r + target.r;
  }
}

class Target {
  constructor() {
    this.x = random(width);
    this.y = 0;
    this.r = 20;
    this.speed = 1;
  }

  update() {
    this.y += this.speed;
  }

  show() {
    image(enemyImg, this.x, this.y, this.r * 2, this.r * 2);
  }

  offScreen() {
    return this.y > height;
  }
}
