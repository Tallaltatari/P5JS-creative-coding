function setup() {
  createCanvas(400, 400);
}

function draw() {
  background("#673AB7");
  fill("#7B3F00")
  circle(180,135,70);
  fill("#FFFF00")
  circle(210,180,70);
  fill("#ff0800")
  circle(150,180,70);
  fill("#7B3F00")
  translate(107,120);
  triangle(10,80,75,190,135,80);
}