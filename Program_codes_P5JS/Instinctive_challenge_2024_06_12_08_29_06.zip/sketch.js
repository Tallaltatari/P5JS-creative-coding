let data = [];

function setup() {
  createCanvas(400, 400);
  for (let i = 0; i < 10; i++) {
    data.push(random(0, 100));
  }
  drawDonutChart(width / 2, height / 2, 300, data);
}

function drawDonutChart(x, y, diameter, data) {
  let lastAngle = 0;
  for (let i = 0; i < data.length; i++) {
    let randomColor = color(random(255), random(255), random(255));
    fill(randomColor);
    let angle = map(data[i], 0, 100, 0, TWO_PI);
    arc(x, y, diameter, diameter, lastAngle, lastAngle + angle, PIE);
    lastAngle += angle;
  }
  
  let innerDiameter = diameter * 0.6;
  fill(255);
  ellipse(x, y, innerDiameter, innerDiameter);
}