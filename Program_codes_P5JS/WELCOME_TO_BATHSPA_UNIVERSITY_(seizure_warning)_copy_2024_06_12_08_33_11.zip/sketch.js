//Fonts and Colors: Val
//Animation: Samuel
//Sound: Tallal
//Mouse Interactions: Fahad

let mySound;
let font;
let numShapes = 50; 
let shapes = [];
let shapeColors = [];
let textPhysics = {
  pos: null,
  vel: null,
  acc: null,
  origPos: null,
  springStrength: 0.05,
  damping: 0.8
};
let frameZPositions = []; 
let frameSpeed = 3; 
let frameSpacing = 200; 
let frameSize = 100; 
let maxFrames = 20;

function preload() {
  mySound = loadSound('1 Minute Timer Lofi.mp3'); 
  font = loadFont('Iomanoid.otf');
}

function setup() {
  createCanvas(600, 400, WEBGL);
  generateShapeColors();
  resetTextPhysics();
  generateFrames();

  
  mySound.play();
}

function draw() {
  background(30, 10, 60);

  
  for (let zPos of frameZPositions) {
    drawFrame(zPos);
  }

  
  updateFramePositions();

  
  for (let i = 0; i < min(numShapes, shapes.length); i++) {
    // Draw shapes code here...
  }

  
  updateTextPhysics();
  displayText();
}

function generateShapeColors() {
  for (let i = 0; i < numShapes; i++) {
    let hue;
    if (i % 4 === 0) {
      // Sunset orange
      hue = random(20, 40);
    } else if (i % 4 === 1) {
      // Green
      hue = random(100, 130);
    } else if (i % 4 === 2) {
      // Dark blue
      hue = random(200, 240);
    } else {
      // Pink
      hue = random(300, 330);
    }
    let colorValue = color(hue, 100, 100);
    shapeColors.push(colorValue);
  }
}

function generateFrames() {
  let initialZ = -maxFrames * frameSpacing / 2;
  for (let i = 0; i < maxFrames; i++) {
    frameZPositions.push(initialZ + i * frameSpacing);
  }
}

function resetTextPhysics() {
  textPhysics.origPos = createVector(width / 2, height / 2);
  textPhysics.pos = textPhysics.origPos.copy();
  textPhysics.vel = createVector();
  textPhysics.acc = createVector();
}

function updateTextPhysics() {
  let attractor = createVector(width / 2, height / 2);
  let force = p5.Vector.sub(attractor, textPhysics.pos);
  force.mult(textPhysics.springStrength);
  textPhysics.acc.add(force);
  textPhysics.vel.add(textPhysics.acc);
  textPhysics.vel.mult(textPhysics.damping);
  textPhysics.pos.add(textPhysics.vel);
  textPhysics.acc.mult(0);
}

function displayText() {
  textFont(font);
  textSize(32);
  textAlign(CENTER, CENTER); 
  fill(255); 

  
  let time = frameCount * 0.05; 
  let neonColor = getColorFromTime(time);

 
  text("WELCOME TO METAVERSE", 0, 0);
}

function drawFrame(zPos) {
  push(); // Save current transformation matrix
  translate(0, 0, zPos);
  noFill();
  stroke(255, 105, 180); // Pink color
  strokeWeight(3);
  box(frameSize);
  pop(); // Restore previous transformation matrix
}

function updateFramePositions() {
  for (let i = 0; i < maxFrames; i++) {
    frameZPositions[i] += frameSpeed;
    // Reset frame position if it goes beyond the screen
    if (frameZPositions[i] > width / 1 + frameSpacing) {
      frameZPositions[i] = frameZPositions[i % maxFrames] - maxFrames * frameSpacing / 2;
    }
  }
}

function getColorFromTime(time) {
  // Define neon colors
  let neonColors = [
    color(255, 165, 0),
    color(0, 191, 255), 
    color(255, 20, 147),
    color(255, 215, 0),
    color(0, 128, 0),
    color(0, 0, 255),
    color(128, 0, 128),
    color(255, 0, 0) 
  ];

  
  let index = floor(time) % neonColors.length;
  return neonColors[index];
}
