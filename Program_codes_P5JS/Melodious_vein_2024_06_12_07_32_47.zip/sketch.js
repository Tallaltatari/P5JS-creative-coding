function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  fill('#FFEB3B');
  noStroke();
  ellipse(300,200,50);
   fill('#3F51B5');
  noStroke();
  square(210,175,55);
   fill('#F44336');
  noStroke();
  triangle(175,175,200,230,150,230);
}