let song;
let fft;

function preload() {
  song = loadSound('Mozart.mp3');
}

function setup() {
  createCanvas(600, 400);
  fft = new p5.FFT();
}

function draw() {
  background(0);
  let spectrum = fft.analyze();
  fill("yellow");
  for (let i = 0; i < spectrum.length; i++) {
    let amp = spectrum[i];
    let y = map(amp, 0, 256, height, 0);
    rect(i * 10, y, 10, height - y);
  }
}

function mousePressed() {
  if (song.isPlaying()) {
    song.pause();
  } else {
    song.play();
  }
}
