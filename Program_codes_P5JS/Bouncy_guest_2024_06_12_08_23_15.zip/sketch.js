class Ball {
  constructor(x, y, radius, color) {
    this.x = random(0,400); 
    this.y = random(0,400); 
    this.radius = random(4,40); 
    this.color = (random(255), random(255), random(255));
    this.velocityX = random(-5, 5); 
    this.velocityY = random(-5, 5); 
  }

  display() {
    fill(this.color); 
    noStroke(); 
    ellipse(this.x, this.y, this.radius * 2, this.radius * 2);
    ellipse(this.x, this.y, this.radius * 2, this.radius * 2);
    ellipse(this.x, this.y, this.radius * 2, this.radius * 2);
    ellipse(this.x, this.y, this.radius * 2, this.radius * 2);
    ellipse(this.x, this.y, this.radius * 2, this.radius * 2);
    ellipse(this.x, this.y, this.radius * 2, this.radius * 2);// 
  }


  update() {
    this.x += this.velocityX; 
    this.y += this.velocityY; 

    
    if (this.x + this.radius >= width || this.x - this.radius <= 0) {
      this.velocityX *= -1; 
    }
    if (this.y + this.radius >= height || this.y - this.radius <= 0) {
      this.velocityY *= -1; 
    }
  }
}

let myBall; 

function setup() {
  createCanvas(400, 400);
  
  // Create an instance of the Ball class with x-coordinate, y-coordinate, radius, and color
  myBall = new Ball(width / 2, height / 2, 20, color(255, 0, 0));
  myBall2 = new Ball(width / 2, height / 2, 20, color(255, 0, 0));
  myBall3 = new Ball(width / 2, height / 2, 20, color(255, 0, 0));
  myBall4 = new Ball(width / 2, height / 2, 20, color(255, 0, 0));
  myBall5 = new Ball(width / 2, height / 2, 20, color(255, 0, 0));
  myBall6 = new Ball(width / 2, height / 2, 20, color(255, 0, 0));// Red ball
}

function draw() {
  background(220);
  
  // Update and display the ball
  myBall.update();
  myBall2.update();
  myBall3.update();
  myBall4.update();
  myBall5.update();
  myBall6.update();
  myBall.display();
  myBall2.display();
  myBall3.display();
  myBall4.display();
  myBall5.display();
  myBall6.display();
}