var img;
function preload() {
  img = loadImage("Zach.jpg");
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  image(img,0,0,img.height/8,img.width/8);
  filter(ERODE,img);
  image(img,0,190,img.height/8,img.width/8);
  filter(DILATE,img);
}